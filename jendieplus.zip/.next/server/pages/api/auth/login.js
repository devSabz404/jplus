"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/auth/login";
exports.ids = ["pages/api/auth/login"];
exports.modules = {

/***/ "bcrypt":
/*!*************************!*\
  !*** external "bcrypt" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ "cookie":
/*!*************************!*\
  !*** external "cookie" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("cookie");

/***/ }),

/***/ "jsonwebtoken":
/*!*******************************!*\
  !*** external "jsonwebtoken" ***!
  \*******************************/
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ "serverless-mysql":
/*!***********************************!*\
  !*** external "serverless-mysql" ***!
  \***********************************/
/***/ ((module) => {

module.exports = require("serverless-mysql");

/***/ }),

/***/ "./lib/db.js":
/*!*******************!*\
  !*** ./lib/db.js ***!
  \*******************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ excuteQuery)\n/* harmony export */ });\n/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! serverless-mysql */ \"serverless-mysql\");\n/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(serverless_mysql__WEBPACK_IMPORTED_MODULE_0__);\n\nconst db = serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default()({\n    config: {\n        host: 'localhost',\n        port: '3306',\n        database: 'iplus',\n        user: 'root',\n        password: \"sabali96\"\n    }\n});\nasync function excuteQuery({ query , values  }) {\n    try {\n        const results = await db.query(query, values);\n        await db.end();\n        return results;\n    } catch (error) {\n        return {\n            error\n        };\n    }\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9saWIvZGIuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQW9DO0FBQ3BDLEtBQUssQ0FBQ0MsRUFBRSxHQUFHRCx1REFBSyxDQUFDLENBQUM7SUFDaEJFLE1BQU0sRUFBRSxDQUFDO1FBQ1BDLElBQUksRUFBRSxDQUFXO1FBQ2pCQyxJQUFJLEVBQUUsQ0FBTTtRQUNaQyxRQUFRLEVBQUMsQ0FBTztRQUNoQkMsSUFBSSxFQUFDLENBQU07UUFDWEMsUUFBUSxFQUFDLENBQVU7SUFFckIsQ0FBQztBQUNILENBQUM7QUFDYyxlQUFlQyxXQUFXLENBQUMsQ0FBQyxDQUFDQyxLQUFLLEdBQUVDLE1BQU0sRUFBQyxDQUFDLEVBQUUsQ0FBQztJQUM1RCxHQUFHLENBQUMsQ0FBQztRQUNILEtBQUssQ0FBQ0MsT0FBTyxHQUFHLEtBQUssQ0FBQ1YsRUFBRSxDQUFDUSxLQUFLLENBQUNBLEtBQUssRUFBRUMsTUFBTTtRQUM1QyxLQUFLLENBQUNULEVBQUUsQ0FBQ1csR0FBRztRQUNaLE1BQU0sQ0FBQ0QsT0FBTztJQUNoQixDQUFDLENBQUMsS0FBSyxFQUFFRSxLQUFLLEVBQUUsQ0FBQztRQUNmLE1BQU0sQ0FBQyxDQUFDO1lBQUNBLEtBQUs7UUFBQyxDQUFDO0lBQ2xCLENBQUM7QUFDSCxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vYWRtaW4tYmltYS8uL2xpYi9kYi5qcz8zZGM5Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBteXNxbCBmcm9tICdzZXJ2ZXJsZXNzLW15c3FsJztcclxuY29uc3QgZGIgPSBteXNxbCh7XHJcbiAgY29uZmlnOiB7XHJcbiAgICBob3N0OiAnbG9jYWxob3N0JyxcclxuICAgIHBvcnQ6ICczMzA2JyxcclxuICAgIGRhdGFiYXNlOidpcGx1cycsXHJcbiAgICB1c2VyOidyb290JyxcclxuICAgIHBhc3N3b3JkOlwic2FiYWxpOTZcIlxyXG4gIFxyXG4gIH1cclxufSk7XHJcbmV4cG9ydCBkZWZhdWx0IGFzeW5jIGZ1bmN0aW9uIGV4Y3V0ZVF1ZXJ5KHsgcXVlcnksIHZhbHVlcyB9KSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlc3VsdHMgPSBhd2FpdCBkYi5xdWVyeShxdWVyeSwgdmFsdWVzKTtcclxuICAgIGF3YWl0IGRiLmVuZCgpO1xyXG4gICAgcmV0dXJuIHJlc3VsdHM7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIHJldHVybiB7IGVycm9yIH07XHJcbiAgfVxyXG59XHJcblxyXG4iXSwibmFtZXMiOlsibXlzcWwiLCJkYiIsImNvbmZpZyIsImhvc3QiLCJwb3J0IiwiZGF0YWJhc2UiLCJ1c2VyIiwicGFzc3dvcmQiLCJleGN1dGVRdWVyeSIsInF1ZXJ5IiwidmFsdWVzIiwicmVzdWx0cyIsImVuZCIsImVycm9yIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./lib/db.js\n");

/***/ }),

/***/ "./pages/api/auth/login.js":
/*!*********************************!*\
  !*** ./pages/api/auth/login.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jsonwebtoken */ \"jsonwebtoken\");\n/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jsonwebtoken__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! cookie */ \"cookie\");\n/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(cookie__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _lib_db__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../lib/db */ \"./lib/db.js\");\n/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! bcrypt */ \"bcrypt\");\n/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(bcrypt__WEBPACK_IMPORTED_MODULE_3__);\n/* eslint-disable import/no-anonymous-default-export */ \n\n\n\n/* harmony default export */ async function __WEBPACK_DEFAULT_EXPORT__(req, res) {\n    const { email , password  } = req.body;\n    const secret = `${process.env.SECRET}`;\n    // Check in the database\n    // if a user with this username\n    // and password exists\n    const user = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_2__[\"default\"])({\n        query: 'SELECT * FROM tbl_user WHERE `emailaddress` =?',\n        values: [\n            email\n        ]\n    });\n    const match = bcrypt__WEBPACK_IMPORTED_MODULE_3___default().compare(password, user[0].password);\n    if (!match) {\n        return res.status(400).json({\n            msg: \"Wrong Password\"\n        });\n    } else if (match) {\n        const token = (0,jsonwebtoken__WEBPACK_IMPORTED_MODULE_0__.sign)({\n            exp: Math.floor(Date.now() / 1000) + 60 * 60 * 24 * 30,\n            id: user[0].user_id,\n            username: user[0].firstname,\n            company: user[0].company,\n            email: user[0].emailaddress,\n            owner: user[0].agent_admin\n        }, secret);\n        const serialised = (0,cookie__WEBPACK_IMPORTED_MODULE_1__.serialize)(\"OursiteJWT\", token, {\n            httpOnly: true,\n            secure: \"development\" !== \"development\",\n            sameSite: \"strict\",\n            maxAge: 60 * 60 * 24 * 30,\n            path: \"/\"\n        });\n        res.setHeader(\"Set-Cookie\", serialised);\n        res.status(200).json({\n            message: user\n        });\n    } else {\n        res.json({\n            message: \"Invalid credentials!\"\n        });\n    }\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9hcGkvYXV0aC9sb2dpbi5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUFBLEVBQXVELHNEQUNwQjtBQUNEO0FBQ087QUFDZDtBQUczQiw2QkFBZSwwQ0FBZ0JJLEdBQUcsRUFBRUMsR0FBRyxFQUFFLENBQUM7SUFDeEMsS0FBSyxDQUFDLENBQUMsQ0FBQ0MsS0FBSyxHQUFFQyxRQUFRLEVBQUMsQ0FBQyxHQUFHSCxHQUFHLENBQUNJLElBQUk7SUFDcEMsS0FBSyxDQUFDQyxNQUFNLE1BQU1DLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDQyxNQUFNO0lBRXBDLEVBQXdCO0lBQ3hCLEVBQStCO0lBQy9CLEVBQXNCO0lBQ3RCLEtBQUssQ0FBQ0MsSUFBSSxHQUFHLEtBQUssQ0FBQ1gsbURBQVcsQ0FBQyxDQUFDO1FBQzlCWSxLQUFLLEVBQUMsQ0FBZ0Q7UUFDdERDLE1BQU0sRUFBRSxDQUFDVDtZQUFBQSxLQUFLO1FBQUEsQ0FBQztJQUNuQixDQUFDO0lBQ0QsS0FBSyxDQUFDVSxLQUFLLEdBQUdiLHFEQUFjLENBQUNJLFFBQVEsRUFBRU0sSUFBSSxDQUFDLENBQUMsRUFBRU4sUUFBUTtJQUV2RCxFQUFFLEdBQUVTLEtBQUssRUFBRSxDQUFDO1FBQUEsTUFBTSxDQUFDWCxHQUFHLENBQUNhLE1BQU0sQ0FBQyxHQUFHLEVBQUVDLElBQUksQ0FBQyxDQUFDQztZQUFBQSxHQUFHLEVBQUUsQ0FBZ0I7UUFBQSxDQUFDO0lBQUMsQ0FBQyxNQUUxRCxFQUFFLEVBQUVKLEtBQUssRUFBRSxDQUFDO1FBQ2YsS0FBSyxDQUFDSyxLQUFLLEdBQUdyQixrREFBSSxDQUNoQixDQUFDO1lBQ0NzQixHQUFHLEVBQUVDLElBQUksQ0FBQ0MsS0FBSyxDQUFDQyxJQUFJLENBQUNDLEdBQUcsS0FBSyxJQUFJLElBQUksRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRTtZQUN0REMsRUFBRSxFQUFFZCxJQUFJLENBQUMsQ0FBQyxFQUFFZSxPQUFPO1lBQ25CQyxRQUFRLEVBQUVoQixJQUFJLENBQUMsQ0FBQyxFQUFFaUIsU0FBUztZQUMzQkMsT0FBTyxFQUFDbEIsSUFBSSxDQUFDLENBQUMsRUFBRWtCLE9BQU87WUFDdkJ6QixLQUFLLEVBQUNPLElBQUksQ0FBQyxDQUFDLEVBQUVtQixZQUFZO1lBQzFCQyxLQUFLLEVBQUNwQixJQUFJLENBQUMsQ0FBQyxFQUFFcUIsV0FBVztRQUUzQixDQUFDLEVBQ0R6QixNQUFNO1FBR1IsS0FBSyxDQUFDMEIsVUFBVSxHQUFHbEMsaURBQVMsQ0FBQyxDQUFZLGFBQUVvQixLQUFLLEVBQUUsQ0FBQztZQUNqRGUsUUFBUSxFQUFFLElBQUk7WUFDZEMsTUFBTSxFQXRDWixDQUFhLGlCQXNDMEIsQ0FBYTtZQUM5Q0MsUUFBUSxFQUFFLENBQVE7WUFDbEJDLE1BQU0sRUFBRSxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFO1lBQ3pCQyxJQUFJLEVBQUUsQ0FBRztRQUNYLENBQUM7UUFFRG5DLEdBQUcsQ0FBQ29DLFNBQVMsQ0FBQyxDQUFZLGFBQUVOLFVBQVU7UUFFdEM5QixHQUFHLENBQUNhLE1BQU0sQ0FBQyxHQUFHLEVBQUVDLElBQUksQ0FBQyxDQUFDO1lBQUN1QixPQUFPLEVBQUM3QixJQUFJO1FBQUMsQ0FBQztJQUN2QyxDQUFDLE1BQU0sQ0FBQztRQUNOUixHQUFHLENBQUNjLElBQUksQ0FBQyxDQUFDO1lBQUN1QixPQUFPLEVBQUUsQ0FBc0I7UUFBQyxDQUFDO0lBQzlDLENBQUM7QUFDSCxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vYWRtaW4tYmltYS8uL3BhZ2VzL2FwaS9hdXRoL2xvZ2luLmpzPzEzMTciXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgaW1wb3J0L25vLWFub255bW91cy1kZWZhdWx0LWV4cG9ydCAqL1xyXG5pbXBvcnQgeyBzaWduIH0gZnJvbSBcImpzb253ZWJ0b2tlblwiO1xyXG5pbXBvcnQgeyBzZXJpYWxpemUgfSBmcm9tIFwiY29va2llXCI7XHJcbmltcG9ydCBleGN1dGVRdWVyeSBmcm9tIFwiLi4vLi4vLi4vbGliL2RiXCI7XHJcbmltcG9ydCBiY3J5cHQgZnJvbSAnYmNyeXB0J1xyXG5cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGFzeW5jIGZ1bmN0aW9uIChyZXEsIHJlcykge1xyXG4gIGNvbnN0IHsgZW1haWwsIHBhc3N3b3JkIH0gPSByZXEuYm9keTtcclxuICBjb25zdCBzZWNyZXQgPSBgJHtwcm9jZXNzLmVudi5TRUNSRVR9YFxyXG5cclxuICAvLyBDaGVjayBpbiB0aGUgZGF0YWJhc2VcclxuICAvLyBpZiBhIHVzZXIgd2l0aCB0aGlzIHVzZXJuYW1lXHJcbiAgLy8gYW5kIHBhc3N3b3JkIGV4aXN0c1xyXG4gIGNvbnN0IHVzZXIgPSBhd2FpdCBleGN1dGVRdWVyeSh7XHJcbiAgICBxdWVyeTonU0VMRUNUICogRlJPTSB0YmxfdXNlciBXSEVSRSBgZW1haWxhZGRyZXNzYCA9PycsXHJcbiAgICB2YWx1ZXMgOltlbWFpbF1cclxufSlcclxuY29uc3QgbWF0Y2ggPSBiY3J5cHQuY29tcGFyZShwYXNzd29yZCwgdXNlclswXS5wYXNzd29yZCk7XHJcblxyXG5pZighbWF0Y2gpIHtyZXR1cm4gcmVzLnN0YXR1cyg0MDApLmpzb24oe21zZzogXCJXcm9uZyBQYXNzd29yZFwifSl9XHJcblxyXG4gIGVsc2UgaWYgKG1hdGNoKSB7XHJcbiAgICBjb25zdCB0b2tlbiA9IHNpZ24oXHJcbiAgICAgIHtcclxuICAgICAgICBleHA6IE1hdGguZmxvb3IoRGF0ZS5ub3coKSAvIDEwMDApICsgNjAgKiA2MCAqIDI0ICogMzAsIC8vIDMwIGRheXNcclxuICAgICAgICBpZDogdXNlclswXS51c2VyX2lkLFxyXG4gICAgICAgIHVzZXJuYW1lOiB1c2VyWzBdLmZpcnN0bmFtZSxcclxuICAgICAgICBjb21wYW55OnVzZXJbMF0uY29tcGFueSxcclxuICAgICAgICBlbWFpbDp1c2VyWzBdLmVtYWlsYWRkcmVzcyxcclxuICAgICAgICBvd25lcjp1c2VyWzBdLmFnZW50X2FkbWluLFxyXG4gICAgIFxyXG4gICAgICB9LFxyXG4gICAgICBzZWNyZXRcclxuICAgICk7XHJcblxyXG4gICAgY29uc3Qgc2VyaWFsaXNlZCA9IHNlcmlhbGl6ZShcIk91cnNpdGVKV1RcIiwgdG9rZW4sIHtcclxuICAgICAgaHR0cE9ubHk6IHRydWUsXHJcbiAgICAgIHNlY3VyZTogcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwiZGV2ZWxvcG1lbnRcIixcclxuICAgICAgc2FtZVNpdGU6IFwic3RyaWN0XCIsXHJcbiAgICAgIG1heEFnZTogNjAgKiA2MCAqIDI0ICogMzAsXHJcbiAgICAgIHBhdGg6IFwiL1wiLFxyXG4gICAgfSk7XHJcblxyXG4gICAgcmVzLnNldEhlYWRlcihcIlNldC1Db29raWVcIiwgc2VyaWFsaXNlZCk7XHJcblxyXG4gICAgcmVzLnN0YXR1cygyMDApLmpzb24oeyBtZXNzYWdlOnVzZXIgfSk7XHJcbiAgfSBlbHNlIHtcclxuICAgIHJlcy5qc29uKHsgbWVzc2FnZTogXCJJbnZhbGlkIGNyZWRlbnRpYWxzIVwiIH0pO1xyXG4gIH1cclxufSJdLCJuYW1lcyI6WyJzaWduIiwic2VyaWFsaXplIiwiZXhjdXRlUXVlcnkiLCJiY3J5cHQiLCJyZXEiLCJyZXMiLCJlbWFpbCIsInBhc3N3b3JkIiwiYm9keSIsInNlY3JldCIsInByb2Nlc3MiLCJlbnYiLCJTRUNSRVQiLCJ1c2VyIiwicXVlcnkiLCJ2YWx1ZXMiLCJtYXRjaCIsImNvbXBhcmUiLCJzdGF0dXMiLCJqc29uIiwibXNnIiwidG9rZW4iLCJleHAiLCJNYXRoIiwiZmxvb3IiLCJEYXRlIiwibm93IiwiaWQiLCJ1c2VyX2lkIiwidXNlcm5hbWUiLCJmaXJzdG5hbWUiLCJjb21wYW55IiwiZW1haWxhZGRyZXNzIiwib3duZXIiLCJhZ2VudF9hZG1pbiIsInNlcmlhbGlzZWQiLCJodHRwT25seSIsInNlY3VyZSIsInNhbWVTaXRlIiwibWF4QWdlIiwicGF0aCIsInNldEhlYWRlciIsIm1lc3NhZ2UiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/api/auth/login.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/api/auth/login.js"));
module.exports = __webpack_exports__;

})();