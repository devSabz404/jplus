"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/auth/register_service";
exports.ids = ["pages/api/auth/register_service"];
exports.modules = {

/***/ "bcrypt":
/*!*************************!*\
  !*** external "bcrypt" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ "serverless-mysql":
/*!***********************************!*\
  !*** external "serverless-mysql" ***!
  \***********************************/
/***/ ((module) => {

module.exports = require("serverless-mysql");

/***/ }),

/***/ "./lib/db.js":
/*!*******************!*\
  !*** ./lib/db.js ***!
  \*******************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ excuteQuery)\n/* harmony export */ });\n/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! serverless-mysql */ \"serverless-mysql\");\n/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(serverless_mysql__WEBPACK_IMPORTED_MODULE_0__);\n\nconst db = serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default()({\n    config: {\n        host: 'localhost',\n        port: '3306',\n        database: 'iplus',\n        user: 'root',\n        password: \"sabali96\"\n    }\n});\nasync function excuteQuery({ query , values  }) {\n    try {\n        const results = await db.query(query, values);\n        await db.end();\n        return results;\n    } catch (error) {\n        return {\n            error\n        };\n    }\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9saWIvZGIuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQW9DO0FBQ3BDLEtBQUssQ0FBQ0MsRUFBRSxHQUFHRCx1REFBSyxDQUFDLENBQUM7SUFDaEJFLE1BQU0sRUFBRSxDQUFDO1FBQ1BDLElBQUksRUFBRSxDQUFXO1FBQ2pCQyxJQUFJLEVBQUUsQ0FBTTtRQUNaQyxRQUFRLEVBQUMsQ0FBTztRQUNoQkMsSUFBSSxFQUFDLENBQU07UUFDWEMsUUFBUSxFQUFDLENBQVU7SUFFckIsQ0FBQztBQUNILENBQUM7QUFDYyxlQUFlQyxXQUFXLENBQUMsQ0FBQyxDQUFDQyxLQUFLLEdBQUVDLE1BQU0sRUFBQyxDQUFDLEVBQUUsQ0FBQztJQUM1RCxHQUFHLENBQUMsQ0FBQztRQUNILEtBQUssQ0FBQ0MsT0FBTyxHQUFHLEtBQUssQ0FBQ1YsRUFBRSxDQUFDUSxLQUFLLENBQUNBLEtBQUssRUFBRUMsTUFBTTtRQUM1QyxLQUFLLENBQUNULEVBQUUsQ0FBQ1csR0FBRztRQUNaLE1BQU0sQ0FBQ0QsT0FBTztJQUNoQixDQUFDLENBQUMsS0FBSyxFQUFFRSxLQUFLLEVBQUUsQ0FBQztRQUNmLE1BQU0sQ0FBQyxDQUFDO1lBQUNBLEtBQUs7UUFBQyxDQUFDO0lBQ2xCLENBQUM7QUFDSCxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vYWRtaW4tYmltYS8uL2xpYi9kYi5qcz8zZGM5Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBteXNxbCBmcm9tICdzZXJ2ZXJsZXNzLW15c3FsJztcclxuY29uc3QgZGIgPSBteXNxbCh7XHJcbiAgY29uZmlnOiB7XHJcbiAgICBob3N0OiAnbG9jYWxob3N0JyxcclxuICAgIHBvcnQ6ICczMzA2JyxcclxuICAgIGRhdGFiYXNlOidpcGx1cycsXHJcbiAgICB1c2VyOidyb290JyxcclxuICAgIHBhc3N3b3JkOlwic2FiYWxpOTZcIlxyXG4gIFxyXG4gIH1cclxufSk7XHJcbmV4cG9ydCBkZWZhdWx0IGFzeW5jIGZ1bmN0aW9uIGV4Y3V0ZVF1ZXJ5KHsgcXVlcnksIHZhbHVlcyB9KSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlc3VsdHMgPSBhd2FpdCBkYi5xdWVyeShxdWVyeSwgdmFsdWVzKTtcclxuICAgIGF3YWl0IGRiLmVuZCgpO1xyXG4gICAgcmV0dXJuIHJlc3VsdHM7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIHJldHVybiB7IGVycm9yIH07XHJcbiAgfVxyXG59XHJcblxyXG4iXSwibmFtZXMiOlsibXlzcWwiLCJkYiIsImNvbmZpZyIsImhvc3QiLCJwb3J0IiwiZGF0YWJhc2UiLCJ1c2VyIiwicGFzc3dvcmQiLCJleGN1dGVRdWVyeSIsInF1ZXJ5IiwidmFsdWVzIiwicmVzdWx0cyIsImVuZCIsImVycm9yIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./lib/db.js\n");

/***/ }),

/***/ "./pages/api/auth/register_service.js":
/*!********************************************!*\
  !*** ./pages/api/auth/register_service.js ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _lib_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../lib/db */ \"./lib/db.js\");\n/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bcrypt */ \"bcrypt\");\n/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bcrypt__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst handler = async (req, res)=>{\n    const { firstname , lastname , email , password , confirm  } = req.body;\n    if (password !== confirm) return res.status(400).json({\n        msg: \"Password and Confirm Password do not match\"\n    });\n    const salt = await bcrypt__WEBPACK_IMPORTED_MODULE_1___default().genSalt();\n    const hashPassword = await bcrypt__WEBPACK_IMPORTED_MODULE_1___default().hash(password, salt);\n    try {\n        const results = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_0__[\"default\"])({\n            query: 'INSERT INTO `tbl_user` (firstname,lastname,emailaddress,password) VALUES (?,?,?,?)',\n            values: [\n                firstname,\n                lastname,\n                email,\n                hashPassword\n            ]\n        });\n        console.log(results);\n        return res.json(results);\n    } catch (e) {\n        res.status(500).json({\n            message: e.message\n        });\n    }\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9hcGkvYXV0aC9yZWdpc3Rlcl9zZXJ2aWNlLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBeUM7QUFDZDtBQUUzQixLQUFLLENBQUNFLE9BQU8sVUFBVUMsR0FBRyxFQUFFQyxHQUFHLEdBQUssQ0FBQztJQUNwQyxLQUFLLENBQUMsQ0FBQ0MsQ0FBQUEsU0FBUyxHQUFDQyxRQUFRLEdBQUNDLEtBQUssR0FBQ0MsUUFBUSxHQUFDQyxPQUFPLEdBQUMsR0FBR04sR0FBRyxDQUFDTyxJQUFJO0lBQzdELEVBQUUsRUFBQ0YsUUFBUSxLQUFLQyxPQUFPLEVBQUUsTUFBTSxDQUFDTCxHQUFHLENBQUNPLE1BQU0sQ0FBQyxHQUFHLEVBQUVDLElBQUksQ0FBQyxDQUFDQztRQUFBQSxHQUFHLEVBQUUsQ0FBNEM7SUFBQSxDQUFDO0lBQ3BHLEtBQUssQ0FBQ0MsSUFBSSxHQUFHLEtBQUssQ0FBQ2IscURBQWM7SUFDakMsS0FBSyxDQUFDZSxZQUFZLEdBQUcsS0FBSyxDQUFDZixrREFBVyxDQUFDTyxRQUFRLEVBQUVNLElBQUk7SUFDdkQsR0FBRyxDQUFDLENBQUM7UUFHSCxLQUFLLENBQUNJLE9BQU8sR0FBRyxLQUFLLENBQUNsQixtREFBVyxDQUFDLENBQUM7WUFFakNtQixLQUFLLEVBQUUsQ0FBb0Y7WUFDM0ZDLE1BQU0sRUFBRyxDQUFDZjtnQkFBQUEsU0FBUztnQkFBQ0MsUUFBUTtnQkFBQ0MsS0FBSztnQkFBQ1MsWUFBWTtZQUFBLENBQUM7UUFFbEQsQ0FBQztRQUNESyxPQUFPLENBQUNDLEdBQUcsQ0FBQ0osT0FBTztRQUNuQixNQUFNLENBQUNkLEdBQUcsQ0FBQ1EsSUFBSSxDQUFDTSxPQUFPO0lBQ3pCLENBQUMsQ0FBQyxLQUFLLEVBQUVLLENBQUMsRUFBRSxDQUFDO1FBQ1huQixHQUFHLENBQUNPLE1BQU0sQ0FBQyxHQUFHLEVBQUVDLElBQUksQ0FBQyxDQUFDO1lBQUNZLE9BQU8sRUFBRUQsQ0FBQyxDQUFDQyxPQUFPO1FBQUMsQ0FBQztJQUM3QyxDQUFDO0FBQ0gsQ0FBQztBQUVELGlFQUFldEIsT0FBTyIsInNvdXJjZXMiOlsid2VicGFjazovL2FkbWluLWJpbWEvLi9wYWdlcy9hcGkvYXV0aC9yZWdpc3Rlcl9zZXJ2aWNlLmpzP2Q2NWQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGV4Y3V0ZVF1ZXJ5IGZyb20gJy4uLy4uLy4uL2xpYi9kYic7XHJcbmltcG9ydCBiY3J5cHQgZnJvbSBcImJjcnlwdFwiO1xyXG5cclxuY29uc3QgaGFuZGxlciA9IGFzeW5jIChyZXEsIHJlcykgPT4ge1xyXG4gY29uc3Qge2ZpcnN0bmFtZSxsYXN0bmFtZSxlbWFpbCxwYXNzd29yZCxjb25maXJtfSA9IHJlcS5ib2R5XHJcbmlmKHBhc3N3b3JkICE9PSBjb25maXJtKSByZXR1cm4gcmVzLnN0YXR1cyg0MDApLmpzb24oe21zZzogXCJQYXNzd29yZCBhbmQgQ29uZmlybSBQYXNzd29yZCBkbyBub3QgbWF0Y2hcIn0pO1xyXG4gICAgY29uc3Qgc2FsdCA9IGF3YWl0IGJjcnlwdC5nZW5TYWx0KCk7XHJcbiAgICBjb25zdCBoYXNoUGFzc3dvcmQgPSBhd2FpdCBiY3J5cHQuaGFzaChwYXNzd29yZCwgc2FsdCk7XHJcbiAgdHJ5IHtcclxuICAgIFxyXG5cclxuICAgIGNvbnN0IHJlc3VsdHMgPSBhd2FpdCBleGN1dGVRdWVyeSh7XHJcbiAgICAgIFxyXG4gICAgICBxdWVyeTogJ0lOU0VSVCBJTlRPIGB0YmxfdXNlcmAgKGZpcnN0bmFtZSxsYXN0bmFtZSxlbWFpbGFkZHJlc3MscGFzc3dvcmQpIFZBTFVFUyAoPyw/LD8sPyknICxcclxuICAgICAgdmFsdWVzOiAgW2ZpcnN0bmFtZSxsYXN0bmFtZSxlbWFpbCxoYXNoUGFzc3dvcmRdXHJcbiAgICAgXHJcbiAgICB9KVxyXG4gICAgY29uc29sZS5sb2cocmVzdWx0cylcclxuICAgIHJldHVybiByZXMuanNvbihyZXN1bHRzKVxyXG4gIH0gY2F0Y2ggKGUpIHtcclxuICAgIHJlcy5zdGF0dXMoNTAwKS5qc29uKHsgbWVzc2FnZTogZS5tZXNzYWdlIH0pXHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBoYW5kbGVyIl0sIm5hbWVzIjpbImV4Y3V0ZVF1ZXJ5IiwiYmNyeXB0IiwiaGFuZGxlciIsInJlcSIsInJlcyIsImZpcnN0bmFtZSIsImxhc3RuYW1lIiwiZW1haWwiLCJwYXNzd29yZCIsImNvbmZpcm0iLCJib2R5Iiwic3RhdHVzIiwianNvbiIsIm1zZyIsInNhbHQiLCJnZW5TYWx0IiwiaGFzaFBhc3N3b3JkIiwiaGFzaCIsInJlc3VsdHMiLCJxdWVyeSIsInZhbHVlcyIsImNvbnNvbGUiLCJsb2ciLCJlIiwibWVzc2FnZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/api/auth/register_service.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/api/auth/register_service.js"));
module.exports = __webpack_exports__;

})();