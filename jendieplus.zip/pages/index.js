
import Header from "../frontie/Hero";
import Layout from "../frontie/Layout"

const home = () => {

    return(
        <>
        <Layout>
            <Header/>
        </Layout>
        
        </>
    )
}
export default home