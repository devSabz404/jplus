export default function Approve(){
    

    return(
        <h1>Hello</h1>
    )
}