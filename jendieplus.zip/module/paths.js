const paths = {
    login: '../login',
    register: '../account/register',
  }

  export default paths